//
//  MovieViewModel.swift
//  MVVM PRACTICE
//
//  Created by Yogesh Patel on 07/03/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit

class MovieViewModel: NSObject {

    var artistName: String = ""
    var trackName: String = ""
    var movieData = [MovieViewModel]()
    
    init(movie: MovieModel) {
        self.artistName = movie.artistName
        self.trackName = movie.trackName
    }
    
    func getData(){
        Service.shareInstance.getAllMovieData { (movie, error) in
            if error == nil{
                self.movieData = movie?.map({return MovieViewModel(movie: $0)}) ?? []
                print(self.movieData)
//                DispatchQueue.main.async {
//                    self.tableView.reloadData()
//                }
            }else{
                print("\(String(describing: error))")
            }
        }
    }
    
    func numberOfRow(section:Int) -> Int{
        return movieData.count
    }
    
    func cellForRow(indexPath: IndexPath) -> MovieViewModel{
        return self.movieData[indexPath.row]
    }
    
    
}
