//
//  ViewController.swift
//  MVVM PRACTICE
//
//  Created by Yogesh Patel on 07/03/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var movieVM: MovieViewModel?
    var movieData = [MovieViewModel]()
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        DispatchQueue.main.async {
            self.movieVM?.getData()
        }
        
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movieVM?.numberOfRow(section: section) ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let movie = movieVM?.cellForRow(indexPath: indexPath)
        cell?.textLabel?.text = movie?.artistName
        cell?.detailTextLabel?.text = movie?.trackName
        return cell!
    }
    
}
