//
//  Service.swift
//  MVVM PRACTICE
//
//  Created by Yogesh Patel on 07/03/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit

class Service: NSObject {

   static let shareInstance = Service()
    
    func getAllMovieData(completion: @escaping ([MovieModel]?, Error?) -> ()){
        let urlString = "https://itunes.apple.com/search?media=music&term=bollywood"
        guard let url = URL(string: urlString) else { return }
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let err = error{
                completion(nil, error)
                print("Failed to load data:", err)
            }
            
            guard let data = data else { return }
            do{
                let result = try JSONDecoder().decode(ResultModel.self, from: data)
                var movieData = [MovieModel]()
                for movie in result.results{
                  movieData.append(MovieModel(artistName: movie.artistName, trackName: movie.trackName))
                }
                completion(movieData, nil)
            }catch let jsonErr{
                print("json error:", jsonErr)
            }
        }.resume()
    }
}
