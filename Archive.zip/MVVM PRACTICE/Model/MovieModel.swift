//
//  MovieModel.swift
//  MVVM PRACTICE
//
//  Created by Yogesh Patel on 07/03/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import Foundation
import UIKit


class MovieModel: Decodable{
    
    var artistName: String = ""
    var trackName: String = ""
    
    init(artistName: String, trackName: String){
        self.artistName = artistName
        self.trackName = trackName
    }
    
}

class ResultModel: Decodable{
    
    var results = [MovieModel]()
    
    init(results: [MovieModel]) {
        self.results = results
    }
}
